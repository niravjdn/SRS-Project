# SRS - iGo Project

- Run jar file inside Jar folder

```
java -jar igo.jar
```

or else

Import project as maven in eclipse and run iGOApp.java as a Java Application.

- Go to http://localhost:8080


Credentials 
username : niravjdn@gmail.com
password : user123

Dummy OPUS Card Numbers to link.

1212121212126

7132819765986

12121212121267
